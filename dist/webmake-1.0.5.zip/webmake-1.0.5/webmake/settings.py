
# Whether to show verbose log messages
VERBOSE = False

# Whether to minify/exclude source maps for production
RELEASE = False

# Whether to force compilation of all files, rather than compiling modified
FORCE = False

# The makefile contents & path, and dependencies map
MAKEFILE = None
MAKEFILEPATH = None
