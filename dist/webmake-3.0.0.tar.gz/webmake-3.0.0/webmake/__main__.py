import webmake.main
webmake.main.main()
